#include "gamewidget.h"
#include <QRect>
#include <QPaintEvent>
#include <QtCore>
#include "cabase.h"
#include <QBrush>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <iostream>
#include <fstream>
#include <QKeyEvent>

using namespace std;

CAbase field(30,30);
SnakeFeld field2(30,30);

GameWidget::GameWidget(QWidget *parent) : QWidget(parent)
{   this->resize(this->height(),this->height()); //grösse der einzelnen zellen
    timer->setInterval(100);
    timer2->setInterval(200);
    connect(timer, SIGNAL(timeout()), this, SLOT(nextGeneration()));
    connect(timer2,SIGNAL(timeout()), this, SLOT(Bewegung()));

}

void GameWidget::mousePressEvent(QMouseEvent *e){
    xKor = e->x(); //pixelgrösse
    yKor = e->y();

    xKor = xKor / rectHeight;  //xZellenGrösse bzw Zellenkoordinaten
    yKor = yKor / rectHeight;
    if (xKor < field.getNx() && yKor < field.getNy() and xKor > -1 and yKor > -1){
        field.setzelle(xKor,yKor); //
        update();
    }
}

void GameWidget::mouseMoveEvent(QMouseEvent *e){
    xKor = e->x();  //gibt x-spielfeldgröesse in pixel an xKor
    yKor = e->y();

    xKor = xKor / rectHeight; //teilt pixel-spielfelgroesse durch kleines quadrat, xKor x für dann kleines quadrat
    yKor = yKor / rectHeight;
    if (xKor < field.getNx() && yKor < field.getNy() and xKor > -1 and yKor > -1){
        field.setzelle(xKor,yKor); //setze kleines quadrat auf dem maus is  als lebendig
        update();    //neues malen, ruft paintevent auf
    }
}

void GameWidget::paintEvent(QPaintEvent *event)
{

    this->resize(this->height(),this->height()); //unbenutzt

    rectHeight = this->height() / field.getNx();  //kleines quadrat

    QRect quadrat(0,0,0,0); //erzeuge quadrat
    QBrush colour(Qt::black,Qt::SolidPattern); //Farbe für lebende quadrate
    QBrush colour2(Qt::blue,Qt::SolidPattern); //Farbe für lebende quadrate
    QBrush colour3(Qt::green,Qt::SolidPattern); //Farbe für lebende quadrate
    QPainter painter(this);  //Objektinstanz
    painter.setPen(Qt::red); // Gitter

    if(spiel == 0)
    {
    for(int x = 0; x<field.getNx(); x++)  //Grid for schleife
    {
        for(int y = 0; y<field.getNy(); y++)
        {
            quadrat.setRect(x*rectHeight,y*rectHeight,rectHeight,rectHeight); // quadrat ruft funktion auf die neue grösse fuer quadrat festsetzt

            if(field.getzelle(x,y) == 1)
                painter.fillRect(quadrat,colour);
            else
                painter.drawRect(quadrat); //falls 0, tot, dann wird nur rechteck gezeichnet

        }
    }
    }
    else
        for(int x = 0; x<field2.returnNx(); x++)  //Grid for schleife
        {
            for(int y = 0; y<field2.returnNy(); y++)
            {
                quadrat.setRect(x*rectHeight,y*rectHeight,rectHeight,rectHeight); // quadrat ruft funktion auf die neue grösse fuer quadrat festsetzt

                if(field2.getZelle(x,y) >= 1)
                {painter.fillRect(quadrat,colour);}
                if(field2.getZelle(x,y) == field2.returnLaenge())
                {painter.fillRect(quadrat,colour2);}
                if(field2.getZelle(x,y) == -2)
                {
                    painter.fillRect(quadrat,colour3);
                }
                else
                {painter.drawRect(quadrat);} //falls 0, tot, dann wird nur rechteck gezeichnet
            }
        }
}

void GameWidget::nextGeneration(){

    field.spieldeslebensmitnelementN();
    update();
}



void GameWidget::setTimerIntervall(int arg1){
    timer->setInterval(arg1);
    update();

}

void GameWidget::startGame(){
    if(spiel == 0)
    {timer->start();}
    else
    {
        timer2->start();
    }
}
void GameWidget::stopGame(){
    timer->stop();
    timer2->stop();
}

void GameWidget::clearBoard(){
    if (spiel == 0)
    {
        field.setNx(field.getNx());
        update();
    }
    if (spiel == 1)
    {
        field2.resetspiel();
        field2.setZelle(5,27);
        field2.Bewegung(56);
        field2.Bewegung(56);
        field2.essen();
        update();
    }
}

void GameWidget::UniversumGroesse(int a){
    if (spiel == 0)
    {
        field.setNx(a);
        field.setNy(a);
        update();
    }
    if (spiel == 1)
        update();
}

void GameWidget::Savefield(){
    std::ofstream datafile("savefile.txt");
    if (datafile.is_open())
    {
        datafile << field.getNx() << "\n";
        datafile << field.getNx() << "\n";
        for(int i = 0; i < field.getNx(); i++)
        {
            for(int j = 0; j < field.getNy(); j++){
                datafile << field.getzelle(i,j) << "\n";}
    }
        datafile.close();
    }
    update();
}

void GameWidget::Loadfield(){
    std::ifstream datafile("savefile.txt");
    if (datafile.is_open())
    {
        int a,b = 0;
        datafile >> a;
        datafile >> b;
        field.setNx(a);
        field.setNy(b);
        update();
        for(int i = 0; i < field.getNx(); i++)
        {
            for(int j = 0; j < field.getNy(); j++){
                datafile >> field.altesarray[i][j]; }}
        datafile.close();
        update();}
}

void GameWidget::Bewegung(int a)
{
    if(timer2->isActive())
    {
        field2.Bewegung(a);
        update();
    }
}

void GameWidget::preparefieldsnake(string a)
{

    if( a == "Spiel des Lebens")
    {
        spiel = 0;
        clearBoard();
    }
    if ( a == "Snake")
    {
        spiel = 1;
        clearBoard();
    }
}
