#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "cabase.h"
#include <iostream>
#include <fstream>

using namespace std;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_startButton_clicked()
{
    ui-> gameWidget -> startGame();
}

void MainWindow::on_spinBox_valueChanged(int arg1)
{
   ui->gameWidget->setTimerIntervall(arg1);
}

void MainWindow::on_stopButton_clicked()
{
    ui->gameWidget-> stopGame();

}

void MainWindow::on_clearButton_clicked()
{
    ui->gameWidget-> clearBoard();
}

void MainWindow::on_UniversumSize_valueChanged(int arg1)
{
    ui-> gameWidget -> UniversumGroesse(arg1);
}

void MainWindow::on_saveButton_clicked()
{
    ui-> gameWidget -> Savefield();
}

void MainWindow::on_loadButton_clicked()
{
    ui-> gameWidget-> Loadfield();
}

void MainWindow::keyPressEvent(QKeyEvent *event)
{
    ui->gameWidget->Bewegung(event->key());
}

void MainWindow::on_comboBox_activated(const QString &arg1)
{
    ui->gameWidget->preparefieldsnake(arg1.toStdString());
}
