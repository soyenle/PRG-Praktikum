#include "cabase.h"
#include <iostream>
using namespace std;

SnakeFeld::SnakeFeld(int a, int b)
{
    Laenge = 3;
    Nx = a;
    Ny = b;
    altesfeld = new int*[Nx];
    for(int i = 0; i < Nx; i++)
    {
        altesfeld [i] = new int[Ny];
    }
    for(int i = 0; i < Nx; i++)
    {
        for(int j = 0; j < Ny; j++)
        {
            altesfeld [i] [j] = 0;

        }
    }
}

SnakeFeld::returnNx()
{
    return Nx;
}

SnakeFeld::returnNy()
{
    return Ny;
}

SnakeFeld::~SnakeFeld()
{
    delete altesfeld;
}

void SnakeFeld::setZelle(int a, int b)
{
    kopfzellex = a;
    kopfzelley = b;
    altesfeld [a] [b] = Laenge;
}

SnakeFeld::returnLaenge()
{
    return Laenge;
}

void SnakeFeld::Bewegung(int a)
{
    if((a == 54 and lastInput != 52) or (a == 56 and lastInput != 50) or (a == 50 and lastInput != 56) or (a == 52 and lastInput != 54)){
        lastInput = a;}
    if(bewegungErlaubt == 1)
    {
        switch (lastInput)
        {

        case 54:
            if(kopfzellex + 1 < returnNx() and (altesfeld [kopfzellex + 1] [kopfzelley] == 0 or altesfeld [kopfzellex + 1] [kopfzelley] == -2))
            {
                if(altesfeld [kopfzellex + 1] [kopfzelley] == -2 )
                {
                    kopfzellex = kopfzellex + 1;
                    Laenge++;
                    setZelle(kopfzellex, kopfzelley);
                    essen();
                }
                else
                {
                    kopfzellex = kopfzellex + 1;
                    updateFeld();
                    setZelle(kopfzellex, kopfzelley);
                }
                if(a == 54)
                {lastInput = a;}
            }
            else
            {
                bewegungErlaubt = 0;
                updateFeld();

            }
            break;
        case 56:
            if(kopfzelley - 1 > -1 and (altesfeld [kopfzellex] [kopfzelley - 1] == 0 or altesfeld [kopfzellex] [kopfzelley - 1] == -2))
            {
                if(altesfeld [kopfzellex] [kopfzelley - 1] == -2)
                {
                    kopfzelley = kopfzelley - 1;
                    Laenge++;
                    setZelle(kopfzellex, kopfzelley);
                    essen();

                }
                else
                {
                    kopfzelley = kopfzelley - 1;
                    updateFeld();
                    setZelle(kopfzellex, kopfzelley);
                }
                if(a == 56)
                {lastInput = a;}            }
            else
            {
                bewegungErlaubt = 0;
                updateFeld();

            }
            break;

        case 50:
            if(kopfzelley + 1 < returnNy() and (altesfeld [kopfzellex] [kopfzelley + 1] == 0 or altesfeld [kopfzellex] [kopfzelley + 1] == -2 ))
            {
                if(altesfeld [kopfzellex] [kopfzelley + 1] == -2)
                {
                    kopfzelley = kopfzelley + 1;
                    Laenge++;
                    setZelle(kopfzellex, kopfzelley);
                    essen();
                }

                else
                {
                    kopfzelley = kopfzelley + 1;
                    updateFeld();
                    setZelle(kopfzellex, kopfzelley);
                }
                if(a == 50)
                {lastInput = a;}            }
            else
            {
                bewegungErlaubt = 0;
                updateFeld();

            }
            break;
        case 52:
            if(kopfzellex - 1 > -1 and (altesfeld [kopfzellex - 1] [kopfzelley] == 0 or altesfeld [kopfzellex - 1] [kopfzelley] == -2))
            {
                if(altesfeld [kopfzellex - 1] [kopfzelley] == -2)
                {
                    kopfzellex = kopfzellex - 1;
                    Laenge++;
                    setZelle(kopfzellex, kopfzelley);
                    essen();
                }
                else
                {
                    kopfzellex = kopfzellex - 1;
                    updateFeld();
                    setZelle(kopfzellex, kopfzelley);
                }

                if(a == 52)
                {lastInput = a;}            }
            else
            {
                bewegungErlaubt = 0;
                updateFeld();

            }
            break;

        }
    }
    else
    {
        updateFeld();
    }
}


void SnakeFeld::updateFeld()
{
    for(int i = 0; i < Nx; i++)
    {
        for(int j = 0; j < Ny; j++)
        {
            if(altesfeld [i] [j] > 0)
            {
                altesfeld [i] [j] = altesfeld [i] [j] - 1;
            }
        }
    }
}

int SnakeFeld::getZelle(int a, int b)
{
    return altesfeld [a] [b];
}

void SnakeFeld::resetspiel()
{
    delete altesfeld;
    Laenge = 3;
    bewegungErlaubt = 1;
    altesfeld = new int*[Nx];
    for(int i = 0; i < Nx; i++)
    {
        altesfeld [i] = new int[Ny];
    }
    for(int i = 0; i < Nx; i++)
    {
        for(int j = 0; j < Ny; j++)
        {
            altesfeld [i] [j] = 0;

        }
    }

}

void SnakeFeld::essen()
{
    int essen = 0;
    for (int i = 0; i < Nx; i++)
    {
        for (int j = 0; j < Ny; j++)
        {
            if (altesfeld [i] [j] == -2)
                essen++;

        }
    }
    if (essen == 0)
    {
        bool essenGesetzt = false;
        while( essenGesetzt == false)
        {
            int a = rand()%Nx;
            int b = rand()%Ny;
            if(altesfeld [a] [b] == 0)
            {
                altesfeld [a] [b] = -2;
                essenGesetzt = true;
            }
        }
    }

}
