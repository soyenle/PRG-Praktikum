#ifndef CABASE_H
#define CABASE_H

class CAbase
{

public:

    int Nx;
    int Ny;
    int** altesarray;
    int** neuesarray;
    int input;

    CAbase();
    CAbase(int a, int b) {
        Nx = a;
        Ny = b;
        altesarray = new int* [a];
        neuesarray = new int* [a];
        for (int i = 0; i < a; i++){
            altesarray [i] = new int [b];
            neuesarray [i] = new int [b];}
        for(int i = 0; i < a; i++)
        {for (int j = 0; j < b; j++)
            {altesarray [i] [j] = 0;
             neuesarray [i] [j] = 0;
            }
        }
    }

    int getNx() {
        return Nx;}

    int getNy() {
        return Ny;}

    void setNx(int a) {
        delete altesarray;
        delete neuesarray;
        Nx = a;
        altesarray = new int* [Nx];
        neuesarray = new int* [Nx];
        for (int i = 0; i < Nx; i++){
            altesarray [i] = new int [Ny];
            neuesarray [i] = new int [Ny];}
        for(int i = 0; i < Nx; i++)
        {for (int j = 0; j < Ny; j++)
            {altesarray [i] [j] = 0;
             neuesarray [i] [j] = 0;
            }
        }

    }

    void setNy(int a) {
        for (int j = 0; j < Nx; j++)
        {
            delete altesarray [j];
            delete neuesarray [j];}
        Ny = a;
        for (int i = 0; i < Nx; i++){
            altesarray [i] = new int [Ny];
            neuesarray [i] = new int [Ny];}
        for(int i = 0; i < Nx; i++)
        {for (int j = 0; j < Ny; j++)
            {altesarray [i] [j] = 0;
             neuesarray [i] [j] = 0;
            }
        }


    }

    void setzelle(int a, int b){
        {altesarray [a] [b] = 1;}
    }

    void setzelleNahrung(int a, int b)
    {  altesarray [a][b] = -1;}

    void setzelleBeute(int a, int b)
    {  altesarray [a][b] = 50;}

    void setzelleJaeger(int a, int b)
    {  altesarray [a][b] = 150;}

    int getzelle(int a, int b) {
        return altesarray [a] [b];
    }

    void spieldeslebens(int a, int b){
        int count = 0;
        for(int i = a + Nx - 1; i <= a + Nx + 1; i++){
            for(int j = b + Ny - 1; j <= b + Ny + 1; j++){
                if( altesarray [i % Nx] [j % Ny] == 1 and (a + Nx != i or b + Ny != j) ){
                    count = count + 1;}}
        }

        if (altesarray [a % Nx] [b % Ny] == 1)
        {

            if (count < 2 or count > 3)
                neuesarray [a % Nx] [b % Ny] = 0;
            if (count > 1 and count < 4)
                neuesarray [a % Nx] [b % Ny] = 1;}

        if (count == 3 and altesarray [a % Nx] [b % Ny] == 0)
            neuesarray [a % Nx] [b % Ny] = 1;
    }

    void spieldeslebensmitnelementN() {
        for(int i = 0; i < Nx; i++)
            for (int j = 0; j < Ny; j++)
                spieldeslebens(i,j);
        for(int a = 0; a < Nx; a++)
            for (int b = 0; b < Ny; b++)
                altesarray [a] [b] = neuesarray [a] [b];
    }

    void JaegerFeldEvolution(){
        for(int i = 0; i < Nx; i++)
            for (int j = 0; j < Ny; j++)
                JaegerZelleEvolution(i,j);

        for(int a = 0; a < Nx; a++)  //Speichere das Evolutionsfeld auf dem zu druckendem Feld
            for (int b = 0; b < Ny; b++)
                altesarray [a] [b] = neuesarray [a] [b];

        for(int a = 0; a < Nx; a++) //Reset das Evolutionsfeld
            for (int b = 0; b < Ny; b++)
                neuesarray [a] [b] = 0;
    }

    void JaegerZelleEvolution(int a, int b){ //übergibt eigene Zelle
        for(int i = a + Nx - 1; i <= a + Nx + 1; i++){ //übergibt Nachbarindizes der Zelle
            for(int j = b + Ny - 1; j <= b + Ny + 1; j++){



            if (altesarray [a] [b] >= 100){   //Prüfe ob Zelle Jäger
                  if(altesarray [i % Nx] [j % Ny] <= 50 and altesarray [i % Nx] [j % Ny] > 0 ){ //Prüfe ob Nachbar Beute
                     neuesarray [i % Nx] [j % Ny] = 150; // setze neue Jäger auf Beuteposition auf max.Lebenszeit
                     altesarray [a][b] = 0;
                     neuesarray [a][b] = 0;
                     altesarray [i % Nx] [j % Ny] = 0;}
                  else neuesarray [a][b] = altesarray[a] [b];
                       }

            if (altesarray [a] [b] <= 50 and altesarray [a] [b] > 0 ){   //Prüfe ob Zelle Jäger
                  if(altesarray [i % Nx] [j % Ny] < 0 ){ //Prüfe ob Nachbar Beute
                     neuesarray [i % Nx] [j % Ny] = 50; // setze neue Jäger auf Beuteposition auf max.Lebenszeit
                     altesarray [a][b] = 0;
                     neuesarray [a][b] = 0;
                     altesarray [i % Nx] [j % Ny] = 0;}
                  else neuesarray [a][b] = altesarray[a] [b];
                       }

           if (altesarray [a] [b] < 0){
               neuesarray [a][b] = altesarray[a] [b];}




             }}}











    ~CAbase() {
        delete altesarray;
        delete neuesarray;}

};

class SnakeFeld //Klasse Snake
{
    int bewegungErlaubt = 1;
    int lastInput;
    int Nx;
    int Ny;
    int** altesfeld;
    int Laenge;
    int kopfzellex;
    int kopfzelley;
public: // Deklaration der Methoden
    SnakeFeld(int a, int b);
    int returnNx();
    int returnNy();
    int returnLaenge();
    void setZelle(int a, int b);
    void Bewegung(int a);
    void updateFeld();
    int getZelle(int a, int b);
    void resetspiel();
    void essen();

    ~SnakeFeld();
};


#endif // CABASE_H
