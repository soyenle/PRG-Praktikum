#ifndef GAMEWIDGET_H
#define GAMEWIDGET_H
#include <QTimer>
#include <QWidget>
#include <QKeyEvent>
#include <QString>
#include <string>

class GameWidget : public QWidget
{
    Q_OBJECT
public:
    int xKor,yKor;  // Koordinaten
    int rectHeight; // Grosses Spielfeld(Quadrat)
    int input;
    int spiel = 0; // am Anfang beim Öffnen in GameofLife modus
    int Typ = 0;

    QTimer *timer = new QTimer(this); //erstellt
    QTimer *timer2 = new QTimer(this); //erstellt für Snake
    QTimer *timer3 = new QTimer(this);



    explicit GameWidget(QWidget *parent = nullptr);

    void paintEvent(QPaintEvent *event);

    void mouseMoveEvent(QMouseEvent *e);
    void setTimerIntervall(int arg1);
    void startGame();
    void stopGame();
    void clearBoard();
    void UniversumGroesse(int a);
    void Savefield();
    void Loadfield();
    void preparefieldsnake(std::string a);
    void Organismus(std::string a);

signals:

public slots:
    void nextGeneration();
    void Bewegung(int a = 0);
    void CellEvolutionDirection();
};

#endif // GAMEWIDGET_H
