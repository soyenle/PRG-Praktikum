#include "cabase.h"
#include <iostream>
using namespace std;

SnakeFeld::SnakeFeld(int a, int b) // Konstruktor mit Übergabe von Feldgröße
{
    Laenge = 3; // der Schlange
    Nx = a; // Feldgröße
    Ny = b;
    altesfeld = new int*[Nx]; // 2Dim array, dynamisches
    for(int i = 0; i < Nx; i++)
    {
        altesfeld [i] = new int[Ny];
    }
    for(int i = 0; i < Nx; i++)
    {
        for(int j = 0; j < Ny; j++)
        {
            altesfeld [i] [j] = 0; //Felder auf 0 gesetzt

        }
    }
}

SnakeFeld::returnNx() //Gibt X Größe des Feldes zurück
{
    return Nx;
}

SnakeFeld::returnNy() // Gibt Y Größe des Feldes zurück
{
    return Ny;
}

SnakeFeld::~SnakeFeld() // Destruktor
{
    delete altesfeld;
}

void SnakeFeld::setZelle(int a, int b)
{
    kopfzellex = a; // x koord des kopfes
    kopfzelley = b;
    altesfeld [a] [b] = Laenge; //wert/counter des kopfes
}

SnakeFeld::returnLaenge()
{
    return Laenge;
}

void SnakeFeld::Bewegung(int a) //Evolutionsfunktion bzw. Bewegung übergeben wird tastatureingabe
{ // a=Richtungstasten, entgegengesetzte Richtung nicht erlaubt
    if((a == 54 and lastInput != 52) or (a == 56 and lastInput != 50) or (a == 50 and lastInput != 56) or (a == 52 and lastInput != 54)){
        lastInput = a;} //lastinput überschrieben richtung
    if(bewegungErlaubt == 1) // keine wand
    {
        switch (lastInput) // verarbeitung der richtung
        {

        case 54: //RECHTS
            if(kopfzellex + 1 < returnNx() and (altesfeld [kopfzellex + 1] [kopfzelley] == 0 or altesfeld [kopfzellex + 1] [kopfzelley] == -2))
            { //nicht über den Rand und == 0 nur zu freiem Feld oder == -2 wenn essen da ist
                if(altesfeld [kopfzellex + 1] [kopfzelley] == -2 ) // falls rechtes Feld essen
                {
                    kopfzellex = kopfzellex + 1;
                    Laenge++;
                    setZelle(kopfzellex, kopfzelley); //Kopf wird neu gesetzt nach rechts
                    essen(); // Essen Funktion aufgerufen
                }
                else // falls freies Feld
                {
                    kopfzellex = kopfzellex + 1;
                    updateFeld();
                    setZelle(kopfzellex, kopfzelley); //Kopf wird neu gesetzt nach rechts
                }
                if(a == 54)
                {lastInput = a;}
            }
            else
            {
                bewegungErlaubt = 0; // wand oder Schlange
                updateFeld();

            }
            break;
        case 56: //UNTEN
            if(kopfzelley - 1 > -1 and (altesfeld [kopfzellex] [kopfzelley - 1] == 0 or altesfeld [kopfzellex] [kopfzelley - 1] == -2))
            {
                if(altesfeld [kopfzellex] [kopfzelley - 1] == -2)
                {
                    kopfzelley = kopfzelley - 1;
                    Laenge++;
                    setZelle(kopfzellex, kopfzelley);
                    essen();

                }
                else
                {
                    kopfzelley = kopfzelley - 1;
                    updateFeld();
                    setZelle(kopfzellex, kopfzelley);
                }
                if(a == 56)
                {lastInput = a;}            }
            else
            {
                bewegungErlaubt = 0;
                updateFeld();

            }
            break;

        case 50: // OBEN
            if(kopfzelley + 1 < returnNy() and (altesfeld [kopfzellex] [kopfzelley + 1] == 0 or altesfeld [kopfzellex] [kopfzelley + 1] == -2 ))
            {
                if(altesfeld [kopfzellex] [kopfzelley + 1] == -2)
                {
                    kopfzelley = kopfzelley + 1;
                    Laenge++;
                    setZelle(kopfzellex, kopfzelley);
                    essen();
                }

                else
                {
                    kopfzelley = kopfzelley + 1;
                    updateFeld();
                    setZelle(kopfzellex, kopfzelley);
                }
                if(a == 50)
                {lastInput = a;}            }
            else
            {
                bewegungErlaubt = 0;
                updateFeld();

            }
            break;
        case 52: // LINKS
            if(kopfzellex - 1 > -1 and (altesfeld [kopfzellex - 1] [kopfzelley] == 0 or altesfeld [kopfzellex - 1] [kopfzelley] == -2))
            {
                if(altesfeld [kopfzellex - 1] [kopfzelley] == -2)
                {
                    kopfzellex = kopfzellex - 1;
                    Laenge++;
                    setZelle(kopfzellex, kopfzelley);
                    essen();
                }
                else
                {
                    kopfzellex = kopfzellex - 1;
                    updateFeld();
                    setZelle(kopfzellex, kopfzelley);
                }

                if(a == 52)
                {lastInput = a;}            }
            else
            {
                bewegungErlaubt = 0;
                updateFeld();

            }
            break;

        }
    }
    else
    {
        updateFeld();
    }
}


void SnakeFeld::updateFeld() // Update des Feldes mit -1 Counter
{
    for(int i = 0; i < Nx; i++)
    {
        for(int j = 0; j < Ny; j++)
        {
            if(altesfeld [i] [j] > 0)
            {
                altesfeld [i] [j] = altesfeld [i] [j] - 1;
            } // updated feld, alle zellen counter -1 pro evolution
        }
    }
}

int SnakeFeld::getZelle(int a, int b) // gibt Zellenzustand zurück
{
    return altesfeld [a] [b];
}

void SnakeFeld::resetspiel() // altes Feld gelöscht und Neues Feld erstellt
{
    delete altesfeld;
    Laenge = 3; // Schlangen Länge
    bewegungErlaubt = 1;
    altesfeld = new int*[Nx]; // 2 dim. dynamisches Array
    for(int i = 0; i < Nx; i++)
    {
        altesfeld [i] = new int[Ny];
    }
    for(int i = 0; i < Nx; i++)
    {
        for(int j = 0; j < Ny; j++)
        {
            altesfeld [i] [j] = 0; // alle Felder auf 0

        }
    }

}

void SnakeFeld::essen() // setzt Essen auf Feld
{
    int essen = 0; // 1 heißt Essen ist auf dem Feld, 0 nicht
    for (int i = 0; i < Nx; i++) // überprüft ob auf dem Feld noch Essen ist
    {
        for (int j = 0; j < Ny; j++)
        {
            if (altesfeld [i] [j] == -2) // -2 heißt Essen
                essen++; // essen auf 1 gesetzt

        }
    }
    if (essen == 0) // falls kein Essen mehr auf Feld
    {
        bool essenGesetzt = false;
        while( essenGesetzt == false) // solange bis Essen gesetzt wird
        {
            int a = rand()%Nx; // zufällige Zelle auf Feld
            int b = rand()%Ny;
            if(altesfeld [a] [b] == 0) // Falls Feld frei
            {
                altesfeld [a] [b] = -2; // Essen wird drauf gesetzt
                essenGesetzt = true;
            }
        }
    }

}
