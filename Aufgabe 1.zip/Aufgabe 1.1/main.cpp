#include <iostream>

using namespace std;

int A1 [30] [30];
int* A2 = new int[30*30];
int input;

int main()
{

    cout << "Hello World!" << endl;
    for(int i = 0; i < 30; i++){
        for(int j = 0; j < 30; j++){
            A1 [i] [j] = rand()%10;}
    };
    for(int i = 0; i < 30*30; i++){
        A2 [i] = A1 [i / 30] [i % 30];
    };

    do{
        cout << "0. Exit, 1. Change Cell, 2. Reprint." << endl;
        cin >> input;

        switch(input){
        case 0:
            break;

        case 1:
            for(int i = 0; i < 30; i++){
                for(int j = 0; j < 30; j++){
                    A1 [i] [j] = rand()%10;}
            };
            for(int i = 0; i < 30*30; i++){
                A2 [i] = A1 [i / 30] [i % 30];
            };

            break;
        case 2:
            for (int i = 0; i < 900; i++){
                cout << A2 [i] << " ";
                if ((i+1) % 30 == 0) cout << endl;}
            break;
        default:
            cout << "Das Eingegebene war falsch." << endl;
            break;


            }
    }

    while (input != 0);


    return 0;
}
