#include <iostream>
#include "cabase.h"

using namespace std;

int main()
{
    int input;
    CAbase a(30,30);
    a.setzelle(0,0);
    a.setzelle(0,29);
    a.setzelle(29,0);

    do {
        cout << "0. Exit, 1. Evolve, 2. Set alive cell, 3. Reprint, 4. Resize." << endl;
        cin >> input;
        cout << endl;
        switch (input){
        case 0:
            break;
        case 1:
            a.spieldeslebensmitnelementN();
            break;
        case 2:
            int c;
            int d;
            cout << "Geben Sie das Feld ein.";
            cin >> c >> d;
            a.setzelle(c,d);

            break; //zu implementieren
        case 3:
            for(int i = 0; i < a.getNx(); i++)
            {
                for(int j = 0; j < a.getNy(); j++)
                {cout << a.altesarray [i] [j] << " | ";}
                cout << endl;
            }
            break;
        case 4:
            int e,f;
            cout << "Geben Sie die Länge und die Höhe ein" << endl;
            cin >> e >> f;
            a.setNx(e);
            a.setNy(f);
            break;
        }

    }
    while(input != 0);
    a.~CAbase();
    return 0;
}
