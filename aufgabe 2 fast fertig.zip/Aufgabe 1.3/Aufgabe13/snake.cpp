#include "cabase.h"
#include <iostream>
using namespace std;

SnakeFeld::SnakeFeld(int a, int b)
{
    Laenge = 3;
    Nx = a;
    Ny = b;
    altesfeld = new int*[Nx];
    for(int i = 0; i < Nx; i++)
    {
        altesfeld [i] = new int[Ny];
    }
    for(int i = 0; i < Nx; i++)
    {
        for(int j = 0; j < Ny; j++)
        {
            altesfeld [i] [j] = 0;

        }
    }
}

SnakeFeld::returnNx()
{
    return Nx;
}

SnakeFeld::returnNy()
{
    return Ny;
}

SnakeFeld::~SnakeFeld()
{
    delete altesfeld;
}

void SnakeFeld::setZelle(int a, int b)
{
    kopfzellex = a;
    kopfzelley = b;
    altesfeld [a] [b] = Laenge;
}

SnakeFeld::returnLaenge()
{
    return Laenge;
}

void SnakeFeld::Bewegung(int a)
{
    if((a == 54 and lastInput != 52) or (a == 56 and lastInput != 50) or (a == 50 and lastInput != 56) or (a == 52 and lastInput != 54)){
        lastInput = a;}
    updateFeld();
    if(bewegungErlaubt == 1)
    {
        switch (lastInput)
        {

        case 54:
            if(kopfzellex + 1 < returnNx() and altesfeld [kopfzellex + 1] [kopfzelley] == 0)
            {
                kopfzellex = kopfzellex + 1;
                setZelle(kopfzellex, kopfzelley);
                if(a == 54)
                {lastInput = a;}
            }
            else
            {
                bewegungErlaubt = 0;
            }
            break;
        case 56:
            if(kopfzelley - 1 > -1 and altesfeld [kopfzellex] [kopfzelley - 1] == 0)
            {
                kopfzelley = kopfzelley - 1;
                setZelle(kopfzellex, kopfzelley);
                if(a == 56)
                {lastInput = a;}            }
            else
            {
                bewegungErlaubt = 0;
            }
            break;

        case 50:
            if(kopfzelley + 1 < returnNy() and altesfeld [kopfzellex] [kopfzelley + 1] == 0)
            {
                kopfzelley = kopfzelley + 1;
                setZelle(kopfzellex, kopfzelley);
                if(a == 50)
                {lastInput = a;}            }
            else
            {
                bewegungErlaubt = 0;
            }
            break;
        case 52:
            if(kopfzellex - 1 > -1 and altesfeld [kopfzellex - 1] [kopfzelley] == 0)
            {
                kopfzellex = kopfzellex - 1;
                setZelle(kopfzellex, kopfzelley);
                if(a == 52)
                {lastInput = a;}            }
            else
            {
                bewegungErlaubt = 0;
            }
            break;

        }
    }
}


void SnakeFeld::updateFeld()
{
    for(int i = 0; i < Nx; i++)
    {
        for(int j = 0; j < Ny; j++)
        {
            if(altesfeld [i] [j] > 0)
            {
                altesfeld [i] [j] = altesfeld [i] [j] - 1;
            }
        }
    }
}

int SnakeFeld::getZelle(int a, int b)
{
    return altesfeld [a] [b];
}



