#include "bewegungsnake.h"
#include <iostream>

using namespace std;

BewegungSnake::BewegungSnake(int a, int b)
{
    Nx = a+2;
    Ny = b+2;
    altesfeld = new int*[Nx];
    neuesfeld = new int*[Ny];
    for(int i = 0; i < Nx; i++)
    {
        altesfeld [i] = new int[Ny];
        neuesfeld [i] = new int[Ny];
    }
    for(int i = 0; i < Nx; i++)
    {
        for(int j = 0; j < Ny; j++)
        {
            if(i != 0 and i != Nx-1 and j != 0 and j != Ny-1)
            {
                altesfeld [i] [j] = +0;
                neuesfeld [i] [j] = +0;
            }
            else
            {
                altesfeld [i] [j] = -1;
                neuesfeld [i] [j] = -1;
            }
        }
    }
}

BewegungSnake::returnNx()
{
    return Nx;
}

BewegungSnake::returnNy()
{
    return Ny;
}

void BewegungSnake::print()
{
    for(int i = 0; i < Nx; i++)
    {
        for(int j = 0; j < Ny; j++)
        {
            cout << altesfeld[i] [j];
        }
        cout << std::endl;
    }
}

BewegungSnake::~BewegungSnake()
{
    delete altesfeld;
    delete neuesfeld;
}
