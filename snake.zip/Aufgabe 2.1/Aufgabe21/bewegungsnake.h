#ifndef BEWEGUNGSNAKE_H
#define BEWEGUNGSNAKE_H


class BewegungSnake
{
    int Nx;
    int Ny;
    int** altesfeld;
    int** neuesfeld;

public:
    BewegungSnake(int a, int b);
    void print();
    int returnNx();
    int returnNy();
    ~BewegungSnake();
};

#endif // BEWEGUNGSNAKE_H
