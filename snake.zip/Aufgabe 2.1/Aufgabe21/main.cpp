#include <iostream>
#include "snakefeld.h"

using namespace std;

int main()
{
    cout << "Hello World!" << endl;
    SnakeFeld a(5,5);
    a.setZelle(1,1);
    a.setZelle(3,2);
    a.print();
    return 0;
}
