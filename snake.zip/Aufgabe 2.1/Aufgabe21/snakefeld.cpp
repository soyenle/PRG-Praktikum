#include "snakefeld.h"
#include <iostream>

using namespace std;

SnakeFeld::SnakeFeld(int a, int b)
{
    Laenge = 3;
    Nx = a+2;
    Ny = b+2;
    altesfeld = new int*[Nx];
    for(int i = 0; i < Nx; i++)
    {
        altesfeld [i] = new int[Ny];
    }
    for(int i = 0; i < Nx; i++)
    {
        for(int j = 0; j < Ny; j++)
        {
            if(i != 0 and i != Nx-1 and j != 0 and j != Ny-1)
            {
                altesfeld [i] [j] = +0;
            }
            else
            {
                altesfeld [i] [j] = -1;
            }
        }
    }
}

SnakeFeld::returnNx()
{
    return Nx;
}

SnakeFeld::returnNy()
{
    return Ny;
}

void SnakeFeld::print()
{
    for(int i = 0; i < Nx; i++)
    {
        for(int j = 0; j < Ny; j++)
        {
            cout << altesfeld[i] [j];
        }
        cout << endl;
    }
    cout << endl;
}

SnakeFeld::~SnakeFeld()
{
    delete altesfeld;
}

void SnakeFeld::setZelle(int a, int b)
{
    kopfzellex = a;
    kopfzelley = b;
    altesfeld [a] [b] = Laenge;
}

/*SnakeFeld::returnLaenge()
{
    return Laenge;
}*/

void SnakeFeld::Bewegung(int a)
{
    if(a == 2 or a == 4 or a == 6 or a == 8){
        lastInput = a;
    }
    updateFeld();
    if(bewegungErlaubt == 1)
    {
        switch (lastInput)
        {

        case 2:
            if(altesfeld [kopfzellex + 1] [kopfzelley] == 0 )
            {
                kopfzellex = kopfzellex + 1;
                setZelle(kopfzellex, kopfzelley);
                lastInput = a;
            }
            else
            {
                bewegungErlaubt = 0;
            }
            break;
        case 4:
            if(altesfeld [kopfzellex] [kopfzelley - 1] == 0 )
            {
                kopfzelley = kopfzelley - 1;
                setZelle(kopfzellex, kopfzelley);
                lastInput = a;
            }
            else
            {
                bewegungErlaubt = 0;
            }
            break;

        case 6:
            if(altesfeld [kopfzellex] [kopfzelley + 1] == 0 )
            {
                kopfzelley = kopfzelley + 1;
                setZelle(kopfzellex, kopfzelley);
                lastInput = a;
            }
            else
            {
                bewegungErlaubt = 0;
            }
            break;
        case 8:
            if(altesfeld [kopfzellex - 1] [kopfzelley] == 0 )
            {
                kopfzellex = kopfzellex - 1;
                setZelle(kopfzellex, kopfzelley);
                lastInput = a;
            }
            else
            {
                bewegungErlaubt = 0;
            }
            break;

        }
    }
}


void SnakeFeld::updateFeld()
{
    for(int i = 0; i < Nx; i++)
    {
        for(int j = 0; j < Ny; j++)
        {
            if(altesfeld [i] [j] > 0)
            {
                altesfeld [i] [j] = altesfeld [i] [j] - 1;
            }
        }
    }
}























