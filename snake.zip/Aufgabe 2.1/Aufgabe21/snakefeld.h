#ifndef SNAKEFELD_H
#define SNAKEFELD_H


class SnakeFeld
{
    int bewegungErlaubt = 1;
    int lastInput;
    int Nx;
    int Ny;
    int** altesfeld;
    int Laenge;
    int kopfzellex;
    int kopfzelley;
public:
    SnakeFeld(int a, int b);
    void print();
    int returnNx();
    int returnNy();
    int returnLaenge();
    void setZelle(int a, int b);
    void Bewegung(int a);
    void updateFeld();

    ~SnakeFeld();
};

#endif // SNAKEFELD_H
